# Centro de Bienestar Animal para Fauna Urbana
## Fundación La Última Esperanza

Proyecto Android nativo en Kotlin. Identificador: `mx.fundacion.ultimaesperanza.bienestaranimal`.

### Funciones de esta versión
- Pantalla principal con teléfono 9831511478, WhatsApp +52 9831511478 y acceso telefónico al 072.
- Formulario de reporte con animal, tipo de incidente, fecha, dirección (número de casa, calle, cruzamientos, colonia, municipio), referencias, descripción y solicitud de confidencialidad.
- Selección de fotografía desde el dispositivo.
- Guardado local de reportes y folio interno.
- Historial local y opción de compartir el texto del reporte por WhatsApp.
- Guía ciudadana y sección de bienestar animal.

### Limitaciones importantes
Esta es una primera versión funcional local. No hay servidor, cuentas de usuario, chat multiusuario, mapa en vivo, panel de moderación, ni envío automático de denuncias a autoridades. El reporte guardado solo existe en el teléfono donde se creó. La fotografía se puede seleccionar, pero no se adjunta automáticamente al mensaje de WhatsApp. El 072 se muestra como contacto municipal indicado por la organización; confirme cobertura y disponibilidad con el municipio. No se debe presentar la aplicación como canal oficial de recepción de denuncias.

### Requisitos para compilar
- Android Studio reciente
- JDK 17 o superior
- Android SDK Platform 35
- Gradle 8.9+ (wrapper recomendado)

Abra la carpeta `CentroBienestarAnimal` en Android Studio, permita sincronizar Gradle y seleccione **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.
