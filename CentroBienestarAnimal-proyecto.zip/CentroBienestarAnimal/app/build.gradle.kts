plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "mx.fundacion.ultimaesperanza.bienestaranimal"
    compileSdk = 35
    defaultConfig {
        applicationId = "mx.fundacion.ultimaesperanza.bienestaranimal"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
