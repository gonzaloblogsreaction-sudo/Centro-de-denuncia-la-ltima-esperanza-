package mx.fundacion.ultimaesperanza.bienestaranimal

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val green = Color.rgb(35, 112, 72)
    private val dark = Color.rgb(34, 48, 40)
    private val pale = Color.rgb(246, 250, 246)
    private val phone = "9831511478"
    private val whatsapp = "529831511478"
    private var selectedPhoto: Uri? = null
    private val fields = linkedMapOf<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 24); setBackgroundColor(pale) }
        val heading = TextView(this).apply { text = title; textSize = 22f; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, 4, 0, 18); setTypeface(null, android.graphics.Typeface.BOLD) }
        root.addView(heading)
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll); return root
    }
    private fun text(root: LinearLayout, value: String, size: Float = 16f) { root.addView(TextView(this).apply { text = value; textSize = size; setTextColor(dark); setPadding(2, 7, 2, 7) }) }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(green); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
    }
    private fun open(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { info("No disponible", "No se encontró una aplicación compatible en este teléfono.") } }
    private fun info(title: String, body: String) { AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("Entendido", null).show() }

    private fun showHome() {
        val root = base("🐾 CENTRO DE BIENESTAR ANIMAL")
        text(root, "PARA FAUNA URBANA\nFUNDACIÓN LA ÚLTIMA ESPERANZA", 18f)
        text(root, "Protección · Denuncia · Rescate · Bienestar", 14f)
        text(root, "Una herramienta ciudadana para documentar posibles casos de maltrato y orientar su canalización. No te pongas en riesgo ni confrontes a nadie.")
        button(root, "🚨 Crear denuncia", ::showReport)
        button(root, "📁 Mis reportes guardados", ::showHistory)
        button(root, "📞 Llamar a la Fundación: 983 151 1478") { open("tel:$phone") }
        button(root, "💬 WhatsApp de la Fundación") { open("https://wa.me/$whatsapp") }
        button(root, "☎ Contactar al 072") { open("tel:072") }
        button(root, "⚖ Derechos y bienestar animal", ::showRights)
        button(root, "📚 Qué necesito para denunciar", ::showGuide)
        button(root, "ℹ Acerca del proyecto") { info("Fundación La Última Esperanza", "Centro de Bienestar Animal para Fauna Urbana. Esta versión guarda borradores localmente en el teléfono y permite compartirlos por WhatsApp. No presenta denuncias automáticamente ante autoridades ni cuenta con un servidor central.") }
        text(root, "Emergencia inmediata con riesgo para personas: 911. La disponibilidad y competencia del 072 debe confirmarse con el municipio.", 13f)
    }

    private fun showGuide() {
        val root = base("¿QUÉ NECESITAS PARA DENUNCIAR?")
        listOf("1. Describe qué ocurrió y qué animal está afectado.", "2. Fecha y hora aproximadas.", "3. Dirección: número de casa, calle principal, cruzamientos y colonia.", "4. Ciudad, municipio y referencias para ubicar el sitio.", "5. Fotografías o videos obtenidos de forma segura y legal.", "6. Datos del posible responsable, solo si los conoces.", "7. Tu nombre y contacto si deseas seguimiento.", "8. Indica si solicitas confidencialidad de tus datos.").forEach { text(root, it) }
        text(root, "No ingreses a propiedades privadas ni te expongas para conseguir pruebas. No publiques domicilios ni datos personales en redes. Conserva los archivos originales.")
        button(root, "Volver al inicio", ::showHome)
    }

    private fun showRights() {
        val root = base("DERECHOS Y BIENESTAR ANIMAL")
        text(root, "Los animales merecen un trato digno y protección frente al sufrimiento evitable.")
        listOf("💧 Agua limpia y alimento suficiente.", "🏠 Refugio y condiciones adecuadas al clima.", "🩺 Atención veterinaria cuando la necesiten.", "🐾 Espacio, higiene y posibilidad de expresar comportamientos naturales.", "❤️ Protección contra golpes, crueldad, abandono y negligencia.", "🌱 Manejo responsable y prevención de reproducción no planificada con orientación veterinaria.").forEach { text(root, it) }
        text(root, "La clasificación de una conducta como infracción o delito y sus sanciones dependen de la legislación vigente y de la autoridad competente. Esta guía es informativa y no sustituye asesoría jurídica.")
        button(root, "Volver al inicio", ::showHome)
    }

    private fun showReport() {
        fields.clear(); selectedPhoto = null
        val root = base("NUEVA DENUNCIA CIUDADANA")
        text(root, "Completa los datos que conozcas. Los campos marcados * son necesarios para guardar el reporte.", 14f)
        fun field(key: String, hint: String, required: Boolean = false, multiline: Boolean = false) {
            val e = EditText(this).apply { this.hint = if (required) "$hint *" else hint; textSize = 15f; setTextColor(dark) }
            if (multiline) { e.minLines = 3; e.gravity = Gravity.TOP }
            root.addView(e, LinearLayout.LayoutParams(-1, -2)); fields[key] = e
        }
        field("name", "Nombre del denunciante", false)
        field("phone", "Teléfono de contacto", false)
        field("animal", "Tipo de animal", true)
        field("incident", "Tipo de situación o posible maltrato", true)
        field("date", "Fecha y hora aproximadas", true)
        field("house", "Número de casa", false)
        field("street", "Calle principal", true)
        field("cross", "Calles de cruzamiento", true)
        field("colony", "Colonia", true)
        field("city", "Ciudad y municipio", true)
        field("reference", "Referencias para localizar el lugar", false)
        field("description", "Descripción de los hechos", true, true)
        val confidential = CheckBox(this).apply { text = "Solicito tratamiento confidencial de mis datos personales"; setTextColor(dark) }; root.addView(confidential)
        val photoLabel = TextView(this).apply { text = "Sin fotografía seleccionada"; setTextColor(dark); setPadding(0, 8, 0, 8) }; root.addView(photoLabel)
        button(root, "📷 Adjuntar fotografía") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
            try { startActivityForResult(intent, 41) } catch (_: Exception) { info("Error", "No se pudo abrir la galería.") }
        }
        button(root, "💾 Guardar reporte en este teléfono") {
            val missing = listOf("animal", "incident", "date", "street", "cross", "colony", "city", "description").filter { fields[it]?.text.isNullOrBlank() }
            if (missing.isNotEmpty()) { info("Faltan datos", "Completa los campos obligatorios marcados con *."); return@button }
            val item = JSONObject().apply {
                put("folio", "LE-${System.currentTimeMillis()}"); put("created", SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()))
                fields.forEach { (k, v) -> put(k, v.text.toString().trim()) }; put("confidential", confidential.isChecked); put("photo", selectedPhoto?.toString() ?: ""); put("status", "Borrador guardado en el teléfono")
            }
            val prefs = getSharedPreferences("reports", MODE_PRIVATE); val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
            arr.put(item); prefs.edit().putString("items", arr.toString()).apply()
            info("Reporte guardado", "Se guardó solo en este teléfono. Folio interno: ${item.getString("folio")}. Para compartirlo con la Fundación, usa el botón de WhatsApp.")
            showHome()
        }
        button(root, "📲 Compartir reporte por WhatsApp") {
            val content = fields.entries.joinToString("\n") { "${it.key}: ${it.value.text}" } + "\nConfidencialidad solicitada: ${confidential.isChecked}\nEvidencia: ${selectedPhoto ?: "No adjunta"}"
            open("https://wa.me/$whatsapp?text=" + Uri.encode("Reporte ciudadano para Fundación La Última Esperanza:\n$content"))
        }
        text(root, "Privacidad: los reportes guardados permanecen en este dispositivo. WhatsApp es un servicio externo; revisa el contenido antes de enviarlo. La fotografía se selecciona en el teléfono, pero esta versión no la transmite automáticamente.", 12f)
        button(root, "Volver al inicio", ::showHome)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            selectedPhoto = data?.data
            selectedPhoto?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
            info("Fotografía seleccionada", "Se eligió una imagen. Recuerda que esta versión no la adjunta automáticamente al mensaje de WhatsApp.")
        }
    }

    private fun showHistory() {
        val root = base("MIS REPORTES GUARDADOS")
        val arr = try { JSONArray(getSharedPreferences("reports", MODE_PRIVATE).getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) text(root, "Todavía no hay reportes guardados en este teléfono.")
        for (i in arr.length() - 1 downTo 0) {
            val item = arr.getJSONObject(i)
            text(root, "${item.optString("folio")} · ${item.optString("created")}\n${item.optString("animal")} — ${item.optString("incident")}\n${item.optString("street")}, ${item.optString("cross")}, ${item.optString("colony")}\nEstado: ${item.optString("status")}")
            button(root, "Compartir este reporte por WhatsApp") {
                val msg = item.toString(2)
                open("https://wa.me/$whatsapp?text=" + Uri.encode("Reporte ciudadano Fundación La Última Esperanza:\n$msg"))
            }
        }
        button(root, "Volver al inicio", ::showHome)
    }
}
